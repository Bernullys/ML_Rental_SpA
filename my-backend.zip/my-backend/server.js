require('dotenv').config();
const express = require('express');
const nodemailer = require('nodemailer');

const app = express();

// Middleware to parse JSON request bodies
app.use(express.json());

// Create email transporter using custom SMTP
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT),
  secure: process.env.SMTP_PORT == 465, // true for port 465 (SSL), false for 587 (TLS)
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// Endpoint to handle contact form submissions
app.post('/contacto', async (req, res) => {
    const { name, lastName, region, email, phone, message } = req.body;
  
    if (!name || !lastName || !region || !email || !phone || !message) {
      return res.status(400).json({ message: 'Por favor, completa todos los campos.' });
    }
  
    const mailOptions = {
      from: process.env.SMTP_FROM,
      to: process.env.SMTP_TO,
      subject: 'Nuevo mensaje de formulario de contacto',
      text: 
        `Nombre(s): ${name}\n` +
        `Apellido(s): ${lastName}\n` +
        `Región: ${region}\n` +
        `Correo electrónico: ${email}\n` +
        `Teléfono: ${phone}\n\n` +
        `Mensaje:\n${message}`,
    };
  
    try {
      await transporter.sendMail(mailOptions);
      res.status(200).json({ message: 'Mensaje enviado correctamente!' });
    } catch (error) {
      console.error('Error al enviar el correo:', error);
      res.status(500).json({ message: 'Error al enviar el mensaje.', error });
    }
  });

// Start the server
const port = process.env.PORT || 3000; // cPanel will ignore this in production
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
